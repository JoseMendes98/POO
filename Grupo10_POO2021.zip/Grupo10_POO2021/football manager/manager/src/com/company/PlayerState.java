package com.company;

public abstract class PlayerState {
}
