package com.company;

public class OutOfGame extends PlayerState {
}
