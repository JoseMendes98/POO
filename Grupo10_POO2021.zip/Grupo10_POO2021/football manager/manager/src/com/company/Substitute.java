package com.company;

public class Substitute extends PlayerState {
}
