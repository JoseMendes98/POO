package com.company;

public class Starting extends PlayerState {
}
