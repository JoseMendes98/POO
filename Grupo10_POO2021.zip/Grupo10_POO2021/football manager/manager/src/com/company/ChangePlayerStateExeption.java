package com.company;

public class ChangePlayerStateExeption extends Exception {
    public ChangePlayerStateExeption() {
    }
}
