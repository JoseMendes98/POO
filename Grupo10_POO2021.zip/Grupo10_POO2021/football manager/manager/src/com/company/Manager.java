package com.company;

public class Manager {

    public static void main(String[] args) {
        UserInterface plm = new UserInterface(5);
    }
}
