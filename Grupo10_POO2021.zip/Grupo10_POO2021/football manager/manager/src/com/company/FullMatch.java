package com.company;

public class FullMatch extends Match {

    public FullMatch(Team teamA, Team teamB) {
        super(teamA, teamB);
    }

    @Override
    public void startMatch() {

    }
}
